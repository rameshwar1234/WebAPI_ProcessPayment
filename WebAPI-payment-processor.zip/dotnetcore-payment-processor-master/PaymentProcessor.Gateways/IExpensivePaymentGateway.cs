﻿using PaymentProcessor.Models.DTO;

namespace PaymentProcessor.Gateways
{
    public interface IExpensivePaymentGateway : IPaymentGateway
    {   
    }
}